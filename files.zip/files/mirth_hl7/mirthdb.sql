--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: mirthdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mirthdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE mirthdb OWNER TO postgres;

\connect mirthdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: alert; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.alert (
    id character(36) NOT NULL,
    name character varying(40) NOT NULL,
    is_enabled boolean NOT NULL,
    expression text,
    template text,
    subject character varying(998)
);


ALTER TABLE public.alert OWNER TO postgres;

--
-- Name: alert_email; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.alert_email (
    alert_id character(36) NOT NULL,
    email character varying(255) NOT NULL
);


ALTER TABLE public.alert_email OWNER TO postgres;

--
-- Name: attachment; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.attachment (
    id character varying(255) NOT NULL,
    message_id character varying(255) NOT NULL,
    attachment_data bytea,
    attachment_size integer,
    attachment_type character varying(40)
);


ALTER TABLE public.attachment OWNER TO postgres;

--
-- Name: channel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.channel (
    id character(36) NOT NULL,
    name character varying(40) NOT NULL,
    description text,
    is_enabled boolean NOT NULL,
    version character varying(40),
    revision integer,
    last_modified timestamp without time zone DEFAULT now(),
    source_connector text,
    destination_connectors text,
    properties text,
    preprocessing_script text,
    postprocessing_script text,
    deploy_script text,
    shutdown_script text
);


ALTER TABLE public.channel OWNER TO postgres;

--
-- Name: channel_alert; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.channel_alert (
    channel_id character(36) NOT NULL,
    alert_id character(36) NOT NULL
);


ALTER TABLE public.channel_alert OWNER TO postgres;

--
-- Name: channel_statistics; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.channel_statistics (
    server_id character(36) NOT NULL,
    channel_id character(36) NOT NULL,
    received numeric,
    filtered numeric,
    sent numeric,
    error numeric,
    queued numeric,
    alerted numeric
);


ALTER TABLE public.channel_statistics OWNER TO postgres;

--
-- Name: code_template; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.code_template (
    id character varying(255) NOT NULL,
    name character varying(40) NOT NULL,
    code_scope character varying(40) NOT NULL,
    code_type character varying(40) NOT NULL,
    tooltip character varying(255),
    code text
);


ALTER TABLE public.code_template OWNER TO postgres;

--
-- Name: configuration; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.configuration (
    category character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.configuration OWNER TO postgres;

--
-- Name: configuration_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.configuration_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.configuration_sequence OWNER TO postgres;

--
-- Name: event_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.event_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_sequence OWNER TO postgres;

--
-- Name: event; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.event (
    id integer DEFAULT nextval('public.event_sequence'::regclass) NOT NULL,
    date_created timestamp without time zone DEFAULT now(),
    name text NOT NULL,
    event_level character varying(40) NOT NULL,
    outcome character varying(40) NOT NULL,
    attributes text,
    user_id integer NOT NULL,
    ip_address character varying(40)
);


ALTER TABLE public.event OWNER TO postgres;

--
-- Name: message_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.message_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_sequence OWNER TO postgres;

--
-- Name: message; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.message (
    sequence_id integer DEFAULT nextval('public.message_sequence'::regclass) NOT NULL,
    id character(36) NOT NULL,
    server_id character(36) NOT NULL,
    channel_id character(36) NOT NULL,
    source character varying(255),
    type character varying(255),
    date_created timestamp without time zone NOT NULL,
    version character varying(40),
    is_encrypted boolean NOT NULL,
    status character varying(40),
    raw_data text,
    raw_data_protocol character varying(40),
    transformed_data text,
    transformed_data_protocol character varying(40),
    encoded_data text,
    encoded_data_protocol character varying(40),
    connector_map text,
    channel_map text,
    response_map text,
    connector_name character varying(255),
    errors text,
    correlation_id character varying(255),
    attachment boolean
);


ALTER TABLE public.message OWNER TO postgres;

--
-- Name: person_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.person_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.person_sequence OWNER TO postgres;

--
-- Name: person; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.person (
    id integer DEFAULT nextval('public.person_sequence'::regclass) NOT NULL,
    username character varying(40) NOT NULL,
    firstname character varying(40),
    lastname character varying(40),
    organization character varying(255),
    email character varying(255),
    phonenumber character varying(40),
    description character varying(255),
    last_login timestamp without time zone DEFAULT now(),
    grace_period_start timestamp without time zone,
    logged_in boolean NOT NULL
);


ALTER TABLE public.person OWNER TO postgres;

--
-- Name: person_password; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.person_password (
    person_id integer NOT NULL,
    password character varying(256) NOT NULL,
    password_date timestamp without time zone DEFAULT now()
);


ALTER TABLE public.person_password OWNER TO postgres;

--
-- Name: schema_info; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.schema_info (
    version character varying(40)
);


ALTER TABLE public.schema_info OWNER TO postgres;

--
-- Name: script; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.script (
    group_id character varying(40) NOT NULL,
    id character varying(40) NOT NULL,
    script text
);


ALTER TABLE public.script OWNER TO postgres;

--
-- Name: template; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE public.template (
    group_id character varying(255) NOT NULL,
    id character varying(255) NOT NULL,
    template text
);


ALTER TABLE public.template OWNER TO postgres;

--
-- Name: alert_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.alert
    ADD CONSTRAINT alert_pkey PRIMARY KEY (id);


--
-- Name: attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: channel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id);


--
-- Name: channel_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.channel_statistics
    ADD CONSTRAINT channel_statistics_pkey PRIMARY KEY (server_id, channel_id);


--
-- Name: code_template_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.code_template
    ADD CONSTRAINT code_template_pkey PRIMARY KEY (id);


--
-- Name: event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT event_pkey PRIMARY KEY (id);


--
-- Name: message_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_id_key UNIQUE (id);


--
-- Name: message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (sequence_id);


--
-- Name: person_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (id);


--
-- Name: script_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.script
    ADD CONSTRAINT script_pkey PRIMARY KEY (group_id, id);


--
-- Name: template_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY public.template
    ADD CONSTRAINT template_pkey PRIMARY KEY (group_id, id);


--
-- Name: attachment_index1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX attachment_index1 ON public.attachment USING btree (message_id);


--
-- Name: message_index1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX message_index1 ON public.message USING btree (channel_id, date_created);


--
-- Name: message_index2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX message_index2 ON public.message USING btree (channel_id, date_created, connector_name);


--
-- Name: message_index3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX message_index3 ON public.message USING btree (channel_id, date_created, raw_data_protocol);


--
-- Name: message_index4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX message_index4 ON public.message USING btree (channel_id, date_created, source);


--
-- Name: message_index5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX message_index5 ON public.message USING btree (channel_id, date_created, status);


--
-- Name: message_index6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX message_index6 ON public.message USING btree (channel_id, date_created, type);


--
-- Name: message_index7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX message_index7 ON public.message USING btree (correlation_id, connector_name);


--
-- Name: message_index8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX message_index8 ON public.message USING btree (attachment) WHERE (attachment = true);


--
-- Name: alert_email_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_email
    ADD CONSTRAINT alert_email_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alert(id) ON DELETE CASCADE;


--
-- Name: channel_alert_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.channel_alert
    ADD CONSTRAINT channel_alert_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alert(id) ON DELETE CASCADE;


--
-- Name: channel_statistics_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.channel_statistics
    ADD CONSTRAINT channel_statistics_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: message_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: person_password_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.person_password
    ADD CONSTRAINT person_password_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.person(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

