# pg_hl7: mirth docker
postgres extentions for handling hl7

this is intended to be used as the client part of a two part Compose project, the other part is the postgres dbase



MIRTH Status;
----------------
To Do: nothing on this container. Mirth connects to the postgres instance on the same docker host and works. All that remains is for a user to install their own Mirth HL7 channels relevent to their site


